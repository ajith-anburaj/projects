<!DOCTYPE html>
<html>
<head>
	<title>forums</title>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <script type="text/javascript" src="js/jquery.min.js"></script>
  	<script type="text/javascript" src="js/bootstrap.js"></script>
    <title>Login</title>
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/post.css" rel="stylesheet">
    <script type="text/javascript">
        function refresh(t)
        {
            setTimeout("location.reload(true);",t);
        }
    </script>
</head>
<body onload="javascript:refresh(3000)">
<!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><b><font size="10">Android forums</font></b></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="index.html">Home</a>
                    </li>
                    <li>
                        <a href="#">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
    <section class="container" style="margin-top: 80px">
    <section class="row clearfix">
        <section class="col-md-12 column">
          
          <ol class="breadcrumb">
                <li><a href="forums.php">Forums</a></li>
                <li><a href="lthread.php">Web design</a></li>
                 <li class="active">Welcome to the forum! (A message from the moderators)   </li>
        </ol>
        </section>
    </section>
    <section class="row clearfix">
        <section class="col-md-12 column">
          
          <div class="row clearfix">
        <div class="col-md-12 column">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <section class="panel-title">
                      <section class="pull-left" id="id">
                        <abbr title="count of posts in this topic">#1</abbr>
                      </section>
                    </section>
                </div>
                <section class="row panel-body">
                    <section class="col-md-9">
                      <h2> <i class="fa fa-smile-o"></i> </h2>
                      <hr>
                      
                        We are all here to help our fellow members and to help continue development on many different devices. This is a development community made up of developers, so we encourage you to work together, help one another and learn together. As a community, we also have guidelines on conduct and general expectations of behavior on the forums. When posting, please treat other members with courtesy and respect. No personal attacks of any kind are allowed and participating in arguments is highly discouraged. If you find a questionable post in a thread you have visited, report it to the moderators and avoid the temptation to police it yourself. Getting involved in the bickering or piling onto a fight only adds to the problems.

                        Finally, if you have problems, comments, or complaints regarding a moderating decision, send a PM to the moderator. There's an appeal process for any decision and the first step is to inform the moderator of your views in a private setting. Hashing these types of issues out on the public forum is counterproductive and will be seen in a negative light.  
                  </section>
                  
                  <section id="user-description" class="col-md-3 ">
                        <section class="well">
                    <div class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-cricle"></i>Forum moderator<span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu">
                      <li><a href="#"><i class="fa fa-user"></i> See profile</a></li>
                      <li><a href="#"><i class="fa fa-envelope"></i> Send PM</a></li>
                      <li class="divider"></li>
                      <li><a href="#"><i class="fa fa-cogs"></i> Manage User (for adminstrator)</a></li>
                    </ul>
                 </div>
                          <figure>
                            <img class="img-rounded img-responsive" src="src/1.png" alt="Forum moderator">
                            <figcaption class="text-center">Admin <br><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-half"></i> </figcaption>
                          </figure>
                          <dl class="dl-horizontal">
                            <dt>Posts:</dt>
                            <dd>1</dd>
                            <dt>Thanks:</dt>
                            <dd>1</dd>
                        </dl>
                        </section>
                  </section>
                  
                </section>
                <div class="panel-footer">
                  <div class="row">
                    <section class="col-md-2 ">
                      <i class="fa fa-thumbs-up "></i><a href="#"> Thanks </a>| <i class="fa fa-warning "></i><a href="#"> Report </a>
                    </section>
                    <section id="thanks" class="col-md-6">
                      
                   </section>
                    <section class="col-md-3">
                      <span class="fa-stack">
                          <i class="fa fa-quote-right fa-stack-1x"></i>
                          <i class="fa fa-comment-o fa-lg fa-stack-1x"></i>
                      <i class="fa fa-mail-reply"></i><a href="#" class="pull-right"> Reply </a>
                    </section>
                </div>
               </div>
            </div>
        </div>
    </div>
          
          
          
        </section>
    </section>
</section>
</body>
</html> 