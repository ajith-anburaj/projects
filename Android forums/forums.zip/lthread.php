<!DOCTYPE html>
<html>
<head>
	<title>forums</title>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <script type="text/javascript" src="js/jquery.min.js"></script>
  	<script type="text/javascript" src="js/bootstrap.js"></script>
    <title>Login</title>
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script type="text/javascript">
        function refresh(t)
        {
            setTimeout("location.reload(true);",t);
        }
    </script>
    <!-- Custom CSS -->
</head>
<body onload="javascript:refresh(5000)">
<!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><b><font size="10">Android forums</font></b></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="index.html">Home</a>
                    </li>
                    <li>
                        <a href="#">Logout</a>
                    </li>
                    <li>
                        <a href="#">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>


<button type="button" style="margin-top:70px;margin-left:30px;margin-bottom:10px" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#largeShoes">
Create thread
</button>

<!-- The modal -->
<div class="modal fade" id="largeShoes" tabindex="-1" role="dialog" aria-labelledby="modalLabelLarge" aria-hidden="true">
<div class="modal-dialog modal-lg">
<div class="modal-content">

<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
<h4 class="modal-title" id="modalLabelLarge">Title</h4>
</div>

<div class="modal-body">
<input type="text" name="input" class="form-control"></input>
</div>
<div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Submit</button>
      </div>
</div>
</div>
</div>
<div class="container">
    <div class="row">
        <section class="panel panel-info">
          <header class="panel-heading">
            <h3>ANDROID GENERAL</h3>
          </header>
          <section class="row panel-body">
            <section class="col-md-6">
              <h4> <a href="a1.php">Welcome to the forum! (A message from the moderators) </a></h4>    
            </section>
            <section class="col-md-2">
              <ul id="post-topic">
                <li class="list-unstyled" id="count"> Posts:0 </li>
              </ul>
            </section>
            <section class="col-md-3">
              <a href="#"><i class="glyphicon glyphicon-user"></i> Moderator</a><br>
              <a href="#"><i class="glyphicon glyphicon-calendar">2017-04-06 7:57 AM</i>    
            </section>
           
          </section>
          
          <hr>
          <section class="row panel-body">
            <section class="col-md-6">
              <h4> <a href="lthread.php">Alcatel OneTouch Pixi 3 (8) WIfi [Model 8070 mt8127] - Custom Recovery [TWRP 3.0.2.0]</a></h4>    
            </section>
            <section class="col-md-2">
              <ul id="post-topic">
                <li class="list-unstyled"> Posts:0 </li>
              </ul>
            </section>
            <section class="col-md-3">
              <a href="#"><i class="glyphicon glyphicon-user"></i> Moderator</a><br>
              <a href="#"><i class="glyphicon glyphicon-calendar"></i> 2017-04-06 7:57 AM  </a>
            </section>
           
          </section>
          
          <hr>
          <section class="row panel-body">
            <section class="col-md-6">
              <h4> <a href="lthread.php">MIUI 7 for Lenovo a536 custom rom </a></h4>    
            </section>
            <section class="col-md-2">
              <ul id="post-topic">
                <li class="list-unstyled"> Posts:0 </li>
              </ul>
            </section>
            <section class="col-md-3">
              <a href="#"><i class="glyphicon glyphicon-user"></i> Moderator</a><br>
              <a href="#"><i class="glyphicon glyphicon-calendar"></i> 2017-04-06 7:57 AM  </a>
            </section>
           
          </section>
          
          <hr>
          <section class="row panel-body">
            <section class="col-md-6">
              <h4> <a href="lthread.php">[ROM][7.0][AOSP] Android N for MeMOPAD 10 FHD LTE</a></h4>    
            </section>
            <section class="col-md-2">
              <ul id="post-topic">
                <li class="list-unstyled"> Posts:0 </li>
              </ul>
            </section>
            <section class="col-md-3">
              <a href="#"><i class="glyphicon glyphicon-user"></i> Moderator</a><br>
              <a href="#"><i class="glyphicon glyphicon-calendar"></i> 2017-04-06 7:57 AM  </a>
            </section>
           
          </section>
          
          <hr>
          <section class="row panel-body">
            <section class="col-md-6">
              <h4> <a href="lthread.php">[HOW-TO] Remove the superuser indicator in CM13/CM14.x/a></h4>    
            </section>
            <section class="col-md-2">
              <ul id="post-topic">
                <li class="list-unstyled"> Posts:0 </li>
              </ul>
            </section>
            <section class="col-md-3">
              <a href="#"><i class="glyphicon glyphicon-user"></i> Moderator</a><br>
              <a href="#"><i class="glyphicon glyphicon-calendar"></i> 2017-04-06 7:57 AM </a>
            </section>
           
          </section>
          
          <hr>
          <section class="row panel-body">
            <section class="col-md-6">
              <h4> <a href="lthread.php"> ✭[GUIDE][26-07-2016]Extreme Battery Life Thread(Greenify+Amplify+Power Nap)✭ </a></h4>    
            </section>
            <section class="col-md-2">
              <ul id="post-topic">
                <li class="list-unstyled"> Posts:0 </li>
              </ul>
            </section>
            <section class="col-md-3">
              <a href="#"><i class="glyphicon glyphicon-user"></i> Moderator</a><br>
              <a href="#"><i class="glyphicon glyphicon-calendar"></i> 2017-04-06 7:57 AM  </a>
            </section>
           
          </section>
          
          <hr>
          <section class="row panel-body">
            <section class="col-md-6">
              <h4> <a href="lthread.php">Lenovo A5000 (Recovery, Root, ROMs, etc.) [REFERENCE/ARCHIVE]</a></h4>    
            </section>
            <section class="col-md-2">
              <ul id="post-topic">
                <li class="list-unstyled"> Posts:0 </li>
              </ul>
            </section>
            <section class="col-md-3">
              <a href="#"><i class="glyphicon glyphicon-user"></i> Moderator</a><br>
              <a href="#"><i class="glyphicon glyphicon-calendar"></i> 2017-04-06 7:57 AM  </a>
            </section>
           
          </section>
          
          <hr>
          <section class="row panel-body">
            <section class="col-md-6">
              <h4> <a href="lthread.php">[SOURCES] Android ROMS highly compressed once again</a></h4>    
            </section>
            <section class="col-md-2">
              <ul id="post-topic">
                <li class="list-unstyled"> Posts:0 </li>
              </ul>
            </section>
            <section class="col-md-3">
              <a href="#"><i class="glyphicon glyphicon-user"></i> Moderator</a><br>
              <a href="#"><i class="glyphicon glyphicon-calendar"></i> 2017-04-06 7:57 AM  </a>
            </section>
           
          </section>            
     </section>
          
  </div>
</div>
</body>
</html>>