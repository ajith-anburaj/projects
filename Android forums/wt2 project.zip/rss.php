<?php
header('Content-Type: application/xml');
$rss = '<?xml version="1.0" encoding="UTF-8" ?>
<rss version="2.0">
<channel>
  <title>Home Page</title>
  <link>ajithkumaraa11.000webhostapp.com</link>
  <description>Discussion forums</description>
	  <author> 
		<name>Ajith kumar</name>
	  </author>
  <item>
    <title>Here’s a Magisk Module to Quickly Debloat your Device, Systemlessly</title>
    <link>ajithkumaraa11.000webhostapp.com</link>
    <description>What’s defined as “bloat” is ultimately up to an end user. Some OEM apps are useful to some people, others find them all useless. If you want to customize </description>
  </item>
  <item>
    <title>Project TwoSnapdragon 835 Hands On and Qualcomm Visit Part 1:</title>
    <link>ajithkumaraa11.000webhostapp.com</link>
    <description>Last week, we were invited to Qualcomm’s Headquarters in San Diego, California, to get a first look and hands on with the Snapdragon 835 in the flesh. We were able…</description>
  </item>
  <item>
    <title>DisplayMate Crowns the Samsung Galaxy S8’s OLED Display as the Best Performing Smartphone Display</title>
    <link>ajithkumaraa11.000webhostapp.com</link>
    <description>Every year since the past 8 years, Samsung attempts to cram the best of what it can mass manufacture into their flagship smartphone, which then becomes a hardware benchmark for</description>
  </item>
  <item>
    <title>Mod Adds the Pixel Nav Bar and Animations to the OnePlus 3/3T with OOS 4.1</title>
    <link>ajithkumaraa11.000webhostapp.com</link>
    <description>XDA Senior Member jassycliq recently released a mod made for the OnePlus 3 and the OnePlus 3T that is running OxygenOS 4.1. It will give you the look of the Pixel navigation...</description>
  </item>
  <item>
    <title>Honor 8 Pro – First Impressions</title>
    <link>ajithkumaraa11.000webhostapp.com</link>
    <description>The Honor 8, released in August of 2016, was a capable flagship and really kickstarted Honor’s journey towards offering more appealing and capable devices with less downsides than their predecessors,...

Read more</description>
  </item>
  <item>
    <title>Anbox allows you to run Android apps on any GNU/Linux OS</title>
    <link>ajithkumaraa11.000webhostapp.com</link>
    <description>Thanks to the widespread proliferation of Google’s Android, developers have flocked to the platform, creating millions of applications for it. Although Android is based on the Linux kernel much like...</description>
  </item>
  <item>
    <title>Video shows how GameCube Emulation performs on the Galaxy S8</title>
    <link>ajithkumaraa11.000webhostapp.com</link>
    <description>We’re a little over a week away from the release of the Samsung Galaxy S8 and Galaxy S8 Plus to consumers. For those avid mobile gamers still on the fence...</description>
  </item>
  <item>
    <title>Best VPN for Android (and PC) in 2017</title>
    <link>ajithkumaraa11.000webhostapp.com</link>
    <description>A VPN service is a must-have to secure your traffic over the public Internet. There are several major benefits: – Privacy: hide your activity from your ISP (or anyone else who might be watching) – Encryption: protect your traffic on public WiFi networks – Circumvention of restrictions: access services blocked by your school, work, ISP</description>
  </item>
  <item>
    <title>Many of the Top 100,000 Android Applications are Teaming Up to Steal Your Location Data</title>
    <link>ajithkumaraa11.000webhostapp.com</link>
    <description>Personal information about you and your smartphone is valuable to certain companies. Big Data, as it is so frequently called, can be anything from application usage patterns, location data, websites</description>
  </item>
</channel>
</rss>
';
echo $rss;
?>