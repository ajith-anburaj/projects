package com.azim;

import java.text.DecimalFormat;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class MyApp extends Activity implements OnClickListener
{
	EditText editRollno;
	Spinner semister;
	Button btnView,clear;

	/** Called when the activity is first created. */


	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		editRollno=(EditText)findViewById(R.id.editRollno);
		semister = (Spinner) findViewById(R.id.semister);
		btnView=(Button)findViewById(R.id.btnView);
		btnView.setOnClickListener(this);
		clear=(Button)findViewById(R.id.clear);
		clear.setOnClickListener(this);

	}
	
	public void onClick(View view)
	{
		if(view==btnView)
		{
			Intent myIntent = new Intent(view.getContext(), Result.class);
			if("Select Semister".equals(semister.getSelectedItem().toString())){
				showMessage("Select Semister", "Please select the semister");
			}else{
				myIntent.putExtra("rollNumber", editRollno.getText().toString());
				myIntent.putExtra("semister", semister.getSelectedItem().toString());
	            startActivityForResult(myIntent, 0);
			}
			
		}
		if(view == clear){
			clearText();
		}
	}
	public void showMessage(String title,String message)
	{
		Builder builder=new Builder(this);
		builder.setCancelable(true);
		builder.setTitle(title);
		builder.setMessage(message);
		builder.show();
	}
	public void clearText()
	{
		editRollno.setText("");
		editRollno.requestFocus();
	}
	public boolean isConnectingToInternet(){
		ConnectivityManager connectivity = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
		if (connectivity != null) 
		{
			NetworkInfo[] info = connectivity.getAllNetworkInfo();
			if (info != null) 
				for (int i = 0; i < info.length; i++) 
					if (info[i].getState() == NetworkInfo.State.CONNECTED)
					{
						return true;
					}
		}
		return false;
	}
	
	public static Double truncate(String data) {             
		DecimalFormat twoDForm = new DecimalFormat("#.##");
		Double value = Double.parseDouble(data);
		return Double.valueOf(twoDForm.format(value));
	}
	
}