package com.azim;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class Result extends Activity {
	TextView institute,semister,studentName;
	String SHEET_NAME = "Result_M14_204_CS_ALL";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_result);
		institute = (TextView) findViewById(R.id.institue);
		semister = (TextView) findViewById(R.id.studentSemister);
		studentName = (TextView) findViewById(R.id.studentName);
		readCSV();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.result, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	protected void readCSV() {
		String csvFile = Environment.getExternalStorageDirectory() + "/download/Result_M14_204_CS_ALL.csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String studentRollNo = getIntent().getStringExtra("rollNumber");
		String studentSemister=getIntent().getStringExtra("semister");
		boolean studentFound = false;
		int indexEX1=4;
		int indexEXTotal=0;
		int indexIA1=0;
		int indexOveralltotal=0;
		int resultIndex = 0;
		int indexIATotal=0;
		int indexQP1 = 0;
		String exTotal = "\"";
		String iATotal = "IA=";
		int noOfSubjectsEX=0;
		int noOfSubjectsIA = 0;
		int i=0;
		i=indexEX1;
		Map<Integer,List<String>> resultMap = new HashMap<Integer,List<String>>();
		try {
			int row = 0;
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {

				if(row==3){
					String[] cells = line.split(cvsSplitBy);
					institute.setText(cells[0]);
				}
				if(row == 4){
					String[] cells = line.split(cvsSplitBy);
					semister.setText(cells[0]);
				}
				if(row>=6 && row<8){
					String[] cells = line.split(cvsSplitBy);					
					for(;i<cells.length;i++){
						if(cells[i].toLowerCase().contains("EX".toLowerCase())){
							if(cells[i].startsWith(exTotal)){
								indexEXTotal=i;
								indexIA1=i+1;
							}
							else{
								noOfSubjectsEX++;
							}
						}
						if(cells[i].toLowerCase().contains("IA".toLowerCase())){
							if(cells[i].contains(iATotal)){
								indexIATotal=indexIA1+noOfSubjectsIA;
								indexOveralltotal=indexIATotal+1;
								resultIndex = indexOveralltotal+1;
								indexQP1 = resultIndex+1;
							}
							else{
								noOfSubjectsIA++;
							}
						}
					}
					i=0;
				}
				if(row>=8){
					if(noOfSubjectsIA<noOfSubjectsEX){
						noOfSubjectsEX=noOfSubjectsIA;
					}
					String[] cells = line.split(cvsSplitBy);
					if(cells.length>0){
						if(studentRollNo.equalsIgnoreCase(cells[1]) && studentSemister.equals(cells[3])){
							studentFound = true;
							studentName.setText("Name:"+cells[2]);
							List<String> headers = new ArrayList<String>();
							headers.add("Subject Code");
							headers.add("Exam Marks");
							headers.add("IA Marks");
							headers.add("Total Marks");
							/*headers.add("Result");*/
							resultMap.put(0, headers);
							for(int j=0;j<noOfSubjectsEX;j++){
								List<String> details = new ArrayList<String>();
								if(indexQP1+j<cells.length){
									if(!cells[indexQP1+j].isEmpty()){
										details.add(cells[indexQP1+j]);
										details.add(cells[indexEX1+j]);
										details.add(cells[indexIA1+j]);
										if(isNumeric(cells[indexIA1+j]) && isNumeric(cells[indexEX1+j])){
											details.add(Double.parseDouble(cells[indexIA1+j])+Double.parseDouble(cells[indexEX1+j])+"");
											resultMap.put(resultMap.size(), details);
										}
										else if(isNumeric(cells[indexEX1+j])){
											details.add(Double.parseDouble(cells[indexEX1+j])+"");
											resultMap.put(resultMap.size(), details);
										}
										else if(isNumeric(cells[indexIA1+j])){
											details.add(Double.parseDouble(cells[indexIA1+j])+"");
											resultMap.put(resultMap.size(), details);
										}
										else if(!cells[indexIA1+j].isEmpty() || !cells[indexEX1+j].isEmpty()){
											details.add(0+"");
											resultMap.put(resultMap.size(), details);
										}

									}
								}
								else{
									break;
								}
							}

							TableLayout tableLayout = (TableLayout) findViewById(R.id.tab);
							//HorizontalScrollView hsv = new HorizontalScrollView(this);
							/*hsv.addView(tableLayout);*/


							createTableLayout(tableLayout,resultMap, resultMap.size(), headers.size(),cells[indexEXTotal],cells[indexIATotal],cells[indexOveralltotal],cells[resultIndex]);


							break;
						}
					}

				}
				row++;
			}
			if(!studentFound){
				institute.setText("Result Not Found in the Sheet \n Verify Reg No or Semister Entered...:(");
				semister.setText("");
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private TableLayout createTableLayout(TableLayout tableLayout, Map<Integer,List<String>> resultMap,int rowCount, int columnCount, String eXTotal, String iATotal, String overalltotal, String result) {
		// 1) Create a tableLayout and its params
		TableLayout.LayoutParams tableLayoutParams = new TableLayout.LayoutParams();
		// 2) create tableRow params
		TableRow.LayoutParams tableRowParams = new TableRow.LayoutParams();
		tableRowParams.setMargins(1, 1, 1, 1);
		tableRowParams.weight = 1;
		for (int i = 0; i < rowCount; i++) {
			// 3) create tableRow
			TableRow tableRow = new TableRow(this);
			tableRow.setBackgroundColor(Color.parseColor("#f07d5c"));
			List<String> details = resultMap.get(i);
			for (int j= 0; j < columnCount; j++) {
				// 4) create textView
				TextView textView = new TextView(this);
				//  textView.setText(String.valueOf(j));
				textView.setBackgroundColor(Color.parseColor("#f07d5c"));
				//textView.setGravity(Gravity.CENTER);

				textView.setText(details.get(j));
				textView.setTextColor(Color.parseColor("#382449"));
				// 5) add textView to tableRow
				tableRow.addView(textView, tableRowParams);
			}

			// 6) add tableRow to tableLayout
			tableLayout.addView(tableRow, tableLayoutParams);
		}


		/*tableRow.setBackgroundColor(Color.BLACK);*/

		TextView totalMarks = new TextView(this);
		TableRow totalMarksTableRow = new TableRow(this);
		totalMarks.setText("Total Exam Marks:"+eXTotal);
		totalMarks.setTextColor(Color.parseColor("#382449"));
		totalMarksTableRow.addView(totalMarks);

		TextView iAMarks = new TextView(this);
		TableRow iAMarksTableRow = new TableRow(this);
		iAMarks.setText("Total IA Marks:"+iATotal);
		iAMarks.setTextColor(Color.parseColor("#382449"));
		iAMarksTableRow.addView(iAMarks);

		TextView grandTotal = new TextView(this);
		TableRow grandTotalTableRow = new TableRow(this);
		grandTotal.setText("Grand Total:"+overalltotal);
		grandTotal.setTextColor(Color.parseColor("#382449"));
		grandTotalTableRow.addView(grandTotal);

		TextView resultMarks = new TextView(this);
		TableRow resultMarksTableRow = new TableRow(this);
		resultMarks.setText("Results:"+result);
		resultMarks.setTextColor(Color.parseColor("#382449"));
		resultMarksTableRow.addView(resultMarks);

		tableLayout.addView(totalMarksTableRow, tableLayoutParams);
		tableLayout.addView(iAMarksTableRow, tableLayoutParams);
		tableLayout.addView(grandTotalTableRow, tableLayoutParams);
		tableLayout.addView(resultMarksTableRow, tableLayoutParams);

		return tableLayout;
	}
	public static boolean isNumeric(String str)  
	{  
		try  
		{  
			double d = Double.parseDouble(str);  
		}  
		catch(NumberFormatException nfe)  
		{  
			return false;  
		}  
		return true;  
	}
}
